//
//  Article.swift
//  itjh
//
//  Created by 黄成都 on 15/2/2.
//  Copyright (c) 2015年 黄成都. All rights reserved.
//

import Foundation

/**
文章列表实体类
*/
class Article: NSObject {
    
    var aid = Int()
    var date = NSString()
    var title = NSString()
    var img = NSString()
    var author_id = Int()
    var author = NSString()
}
